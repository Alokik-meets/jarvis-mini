# JARVIS Mini (MVP)

A small voice assistant that runs in the browser.

## What it does
- Listens through the laptop microphone (Chrome or Edge) and speaks replies out loud
- Opens sites by voice: "open WhatsApp", "open YouTube", "open Gmail" ...
- Searches: "search for black holes", "play lo-fi music" (YouTube)
- Tells the time and date instantly
- Answers anything else using an AI model, and remembers the last few messages
- Optional "always listening" mode: say "Jarvis, open WhatsApp"

## Files
- `index.html` : the whole front end (voice in, voice out, commands)
- `netlify/functions/chat.js` : the AI brain (keeps your API key secret)
- `netlify.toml` : Netlify settings

## Deploy on Netlify
1. Get an API key at https://console.anthropic.com
2. Put this folder on GitHub and connect it in Netlify (New site > Import from Git), or drag the folder into https://app.netlify.com/drop
3. In Netlify: Site configuration > Environment variables > add
   `ANTHROPIC_API_KEY` = your key
4. Redeploy. Open the site in Chrome, click the orb, allow the microphone, and talk.

Note: drag-and-drop works, but Git-based deploys are the most reliable way to get functions working.

## Test on your laptop first
```
npm install -g netlify-cli
export ANTHROPIC_API_KEY=your_key_here
netlify dev
```
Open the localhost link it prints.

## Add your own commands
In `index.html`:
- Add sites to the `SITES` list at the top of the script
- Add new rules inside `localCommand()` (for example "open notepad" cannot work from a website, but "open canva" can)

## Limits (honest ones)
- A website cannot open desktop apps or read files. It can only open web pages and tabs. Real computer control needs a Python version running locally.
- Voice input works in Chrome and Edge, not Firefox.
- Always-listening mode only works while the tab is open.
- Anyone with your site link can use your API key, so add a spending limit in the Anthropic console and don't share the link widely.

## Ideas for the student to extend
Weather by voice, a to-do list saved in localStorage, a wake sound, different voices, a Python version using `pyttsx3` and `speech_recognition` that can truly open apps.
